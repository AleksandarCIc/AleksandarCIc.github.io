﻿namespace uTinyRipper.Converters.Shaders
{
	public class ShaderGLESExporter : ShaderTextExporter
	{
	}
}
