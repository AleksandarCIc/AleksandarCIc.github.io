﻿using uTinyRipper.Classes.GameObjects;

namespace uTinyRipper.Converters.GameObjects
{
	public static class ComponentPairConverter
	{
		public static ComponentPair Convert(IExportContainer container, ComponentPair origin)
		{
			return origin;
		}
	}
}
