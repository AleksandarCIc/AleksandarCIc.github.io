﻿namespace uTinyRipper.Classes.AnimationClips
{
	public enum AnimationType
	{
		Legacy		= 1,
		Mecanim		= 2,
		Human		= 3,
	}
}
