﻿namespace uTinyRipper.Classes.LightmapSettingss
{
	public enum Lightmapper
	{
		Radiosity		= 0,
		Enlighten		= 0,
		PathTracer		= 1,
		ProgressiveCPU	= 1,
		ProgressiveGPU	= 2,
	}
}
