﻿namespace uTinyRipper.Classes.LightmapSettingss
{
	public enum Sampling
	{
		Auto	= 0,
		Fixed	= 1,
	}
}
