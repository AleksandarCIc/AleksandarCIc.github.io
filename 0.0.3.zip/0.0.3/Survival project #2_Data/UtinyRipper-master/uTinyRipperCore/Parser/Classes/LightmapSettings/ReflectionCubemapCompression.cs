﻿namespace uTinyRipper.Classes.LightmapSettingss
{
	public enum ReflectionCubemapCompression
	{
		Uncompressed	= 0,
		Compressed		= 1,
		Auto			= 2,
	}
}
