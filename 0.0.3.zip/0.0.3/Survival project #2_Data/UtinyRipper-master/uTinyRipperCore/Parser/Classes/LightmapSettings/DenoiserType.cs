﻿namespace uTinyRipper.Classes.LightmapSettingss
{
	public enum DenoiserType
	{
		None	= 0,
		Optix	= 1,
	}
}
