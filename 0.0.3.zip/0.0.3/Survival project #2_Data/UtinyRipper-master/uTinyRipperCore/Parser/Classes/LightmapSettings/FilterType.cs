﻿namespace uTinyRipper.Classes.LightmapSettingss
{
	public enum FilterType
	{
		Gaussian	= 0,
		ATrous		= 1,
		None		= 2,
	}
}
