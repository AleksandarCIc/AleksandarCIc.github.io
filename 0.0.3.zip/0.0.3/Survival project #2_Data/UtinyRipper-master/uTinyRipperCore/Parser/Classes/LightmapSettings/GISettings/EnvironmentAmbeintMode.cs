﻿namespace uTinyRipper.Classes.LightmapSettingss
{
	public enum EnvironmentAmbeintMode
	{
		Realtime	= 0,
		Baked		= 1,
	}
}
