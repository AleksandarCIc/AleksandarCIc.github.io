﻿namespace uTinyRipper.Classes.LightmapSettingss
{
	public enum FilterMode
	{
		None		= 0,
		Auto		= 1,
		Advanced	= 2,
	}
}
