﻿namespace uTinyRipper.Classes.LightmapSettingss
{
	public enum GIWorkflowMode
	{
		Iterative	= 0,
		OnDemand	= 1,
		Legacy		= 2,
	}
}
