﻿namespace uTinyRipper.Classes.AudioSources
{
	public enum AudioRolloffMode
	{
		Logarithmic		= 0,
		Linear			= 1,
		Custom			= 2
	}
}
