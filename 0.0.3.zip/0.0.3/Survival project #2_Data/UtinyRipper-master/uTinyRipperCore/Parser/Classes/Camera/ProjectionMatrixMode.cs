﻿namespace uTinyRipper.Classes.Cameras
{
	public enum ProjectionMatrixMode
	{
		Explicit					= 0,
		Implicit					= 1,
		PhysicalPropertiesBased		= 2,
	}
}
