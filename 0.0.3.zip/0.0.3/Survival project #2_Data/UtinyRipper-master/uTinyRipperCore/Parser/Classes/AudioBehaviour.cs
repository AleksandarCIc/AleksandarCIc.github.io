﻿namespace uTinyRipper.Classes
{
	public abstract class AudioBehaviour : Behaviour
	{
		protected AudioBehaviour(AssetInfo assetInfo):
			base(assetInfo)
		{
		}
	}
}
