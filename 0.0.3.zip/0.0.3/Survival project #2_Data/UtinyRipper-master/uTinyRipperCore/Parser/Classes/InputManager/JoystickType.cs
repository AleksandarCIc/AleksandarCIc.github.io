﻿namespace uTinyRipper.Classes.InputManagers
{
	public enum JoystickType
	{
		AllJoysticks	= 0,
		Joystick1		= 1,
		Joystick2		= 2,
		Joystick3		= 3,
		Joystick4		= 4,
		Joystick5		= 5,
		Joystick6		= 6,
		Joystick7		= 7,
		Joystick8		= 8,
		Joystick9		= 9,
		Joystick10		= 10,
		Joystick11		= 11,
		Joystick12		= 12,
		Joystick13		= 13,
		Joystick14		= 14,
		Joystick15		= 15,
		Joystick16		= 16,
	}
}
