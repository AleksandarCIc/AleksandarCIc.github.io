﻿namespace uTinyRipper.Classes.InputManagers
{
	public enum InputAxesDirection
	{
		X			= 0,
		Y			= 1,
		ScrollWheel	= 2,
		_4			= 3,
		_5			= 4,
		_6			= 5,
		_7			= 6,
		_8			= 7,
		_9			= 8,
		_10			= 9,
		_11			= 10,
		_12			= 11,
		_13			= 12,
		_14			= 13,
		_15			= 14,
		_16			= 15,
		_17			= 16,
		_18			= 17,
		_19			= 18,
		_20			= 19,
		_21			= 20,
		_22			= 21,
		_23			= 22,
		_24			= 23,
		_25			= 24,
		_26			= 25,
		_27			= 26,
		_28			= 27,
	}
}
