﻿namespace uTinyRipper.Classes.EditorSettingss
{
	public enum LineEndingsMode
	{
		OSNative	= 0,
		Unix		= 1,
		Windows		= 2,
	}
}
