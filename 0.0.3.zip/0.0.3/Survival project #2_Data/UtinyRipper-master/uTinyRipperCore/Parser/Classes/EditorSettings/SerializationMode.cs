﻿namespace uTinyRipper.Classes.EditorSettingss
{
	public enum SerializationMode
	{
		Mixed			= 0,
		ForceBinary		= 1,
		ForceText		= 2,
	}
}
