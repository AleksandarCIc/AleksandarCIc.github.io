﻿namespace uTinyRipper.Classes.EditorSettingss
{
	public enum ExternalVersionControl
	{
		AutoDetect		= -1,
		Disabled		= 0,
		Generic			= 1,
		Subversion		= 2,
		Perforce		= 3,
		AssetServer		= 4,
	}
}
