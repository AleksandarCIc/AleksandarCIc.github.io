﻿namespace uTinyRipper.Classes.EditorSettingss
{
	public enum EditorBehaviorMode
	{
		Mode3D	= 0,
		Mode2D	= 1,
	}
}
