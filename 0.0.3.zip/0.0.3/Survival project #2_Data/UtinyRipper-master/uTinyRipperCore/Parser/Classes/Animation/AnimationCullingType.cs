﻿namespace uTinyRipper.Classes.Animations
{
	public enum AnimationCullingType
	{
		AlwaysAnimate		= 0,
		BasedOnRenderers	= 1,
		BasedOnClipBounds	= 2,
		BasedOnUserBounds	= 3,
	}
}
