﻿namespace uTinyRipper.Classes
{
	public abstract class LevelGameManager : GameManager
	{
		protected LevelGameManager(AssetInfo assetInfo):
			base(assetInfo)
		{
		}
	}
}