﻿namespace uTinyRipper.Classes.CompositeCollider2Ds
{
	public enum GenerationType
	{
		Synchronous		= 0,
		Manual			= 1,
	}
}
