﻿namespace uTinyRipper.Classes.CompositeCollider2Ds
{
	public enum GeometryType
	{
		Outlines	= 0,
		Polygons	= 1,
	}
}
