﻿namespace uTinyRipper.Classes.Lights
{
	public enum LightType
	{
		Spot,
		Directional,
		Point,
		Area,
	}
}
