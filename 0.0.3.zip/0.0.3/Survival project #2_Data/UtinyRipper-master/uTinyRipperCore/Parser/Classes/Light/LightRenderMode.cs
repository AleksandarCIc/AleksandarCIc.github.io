﻿namespace uTinyRipper.Classes.Lights
{
	public enum LightRenderMode
	{
		Auto,
		ForcePixel,
		ForceVertex,
	}
}
