﻿namespace uTinyRipper.Classes
{
	public abstract class GUIElement : Behaviour
	{
		public GUIElement(AssetInfo assetInfo) :
			base(assetInfo)
		{
		}
	}
}
