﻿namespace uTinyRipper.Classes
{
	public abstract class BaseAnimationTrack : NamedObject
	{
		protected BaseAnimationTrack(AssetInfo assetInfo):
			base(assetInfo)
		{
		}
	}
}