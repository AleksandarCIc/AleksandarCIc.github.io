﻿namespace uTinyRipper.Classes
{
	public sealed class FlareLayer : Behaviour
	{
		public FlareLayer(AssetInfo assetInfo) :
			base(assetInfo)
		{
		}
	}
}
