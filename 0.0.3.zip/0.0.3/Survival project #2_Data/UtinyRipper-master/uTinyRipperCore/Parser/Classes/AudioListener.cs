﻿namespace uTinyRipper.Classes
{
	public sealed class AudioListener : AudioBehaviour
	{
		public AudioListener(AssetInfo assetInfo):
			base(assetInfo)
		{
		}
	}
}
