﻿namespace uTinyRipper.Classes.GraphicsSettingss
{
	public enum LightmapStrippingMode
	{
		Automatic	= 0,
		Custom		= 1,
	}
}
