﻿namespace uTinyRipper.Classes.GraphicsSettingss
{
	public enum BuiltinShaderMode
	{
		None		= 0,
		Builtin		= 1,
		Custom		= 2,
	}
}
