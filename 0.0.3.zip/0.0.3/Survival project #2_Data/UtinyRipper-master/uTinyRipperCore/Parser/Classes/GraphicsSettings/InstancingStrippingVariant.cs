﻿namespace uTinyRipper.Classes.GraphicsSettingss
{
	public enum InstancingStrippingVariant
	{
		StripUnused		= 0,
		StripAll		= 1,
		KeepAll			= 2,
	}
}
