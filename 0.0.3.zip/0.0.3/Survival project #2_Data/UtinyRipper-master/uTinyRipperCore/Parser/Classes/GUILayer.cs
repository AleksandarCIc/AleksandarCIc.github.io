﻿namespace uTinyRipper.Classes
{
	public sealed class GUILayer : Behaviour
	{
		public GUILayer(AssetInfo assetInfo) :
			base(assetInfo)
		{
		}
	}
}
