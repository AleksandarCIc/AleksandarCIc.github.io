﻿namespace uTinyRipper
{
	public interface IEndianReadable
	{
		void Read(EndianReader reader);
	}
}
