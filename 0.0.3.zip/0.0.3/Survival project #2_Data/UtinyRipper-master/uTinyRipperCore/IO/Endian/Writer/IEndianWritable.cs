﻿namespace uTinyRipper
{
	public interface IEndianWritable
	{
		void Write(EndianWriter writer);
	}
}
