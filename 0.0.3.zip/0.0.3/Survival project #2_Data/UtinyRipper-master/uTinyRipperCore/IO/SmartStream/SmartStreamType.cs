﻿namespace uTinyRipper
{
	public enum SmartStreamType
	{
		File,
		Memory,
	}
}
