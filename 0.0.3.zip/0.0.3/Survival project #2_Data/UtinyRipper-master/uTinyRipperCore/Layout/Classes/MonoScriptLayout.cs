﻿using uTinyRipper.Classes;

namespace uTinyRipper.Layout
{
#warning TODO:
	public sealed class MonoScriptLayout
	{
		public MonoScriptLayout(LayoutInfo info)
		{
		}

		public string Name => nameof(MonoScript);
	}
}
