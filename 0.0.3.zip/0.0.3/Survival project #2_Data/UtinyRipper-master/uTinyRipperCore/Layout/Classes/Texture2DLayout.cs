﻿using uTinyRipper.Classes;

namespace uTinyRipper.Layout
{
#warning TODO:
	public sealed class Texture2DLayout
	{
		public Texture2DLayout(LayoutInfo info)
		{
		}

		public string Name => nameof(Texture2D);
	}
}
