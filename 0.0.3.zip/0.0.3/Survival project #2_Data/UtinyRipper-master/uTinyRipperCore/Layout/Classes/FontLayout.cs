﻿using uTinyRipper.Classes;

namespace uTinyRipper.Layout
{
#warning TODO:
	public sealed class FontLayout
	{
		public FontLayout(LayoutInfo info)
		{
		}

		public string Name => nameof(Font);
	}
}
